# MeetingHub

Projectgeheugen voor Marten van Toor. Zet Pocket transcripten en doorgestuurde
mail om in een levende status per project.

## Snel starten met Claude Code

```bash
git init meetinghub && cd meetinghub
# kopieer CLAUDE.md, db/, prompts/ en docs/ hierheen
claude
```

Eerste opdracht aan Claude Code:

> Lees CLAUDE.md, db/schema.sql en docs/eval.md. Zet een monorepo op met
> apps/web (Next.js 15) en apps/worker, packages/db (drizzle) en packages/core.
> Implementeer sprint 1: het schema als drizzle migratie, de Pocket webhook op
> POST /api/ingest/pocket, de extractie uit packages/core met prompts/extract-v1.md,
> en een detailpagina /bronnen/[id] die de ruwe bron naast de extractie toont.
> Verder niets. Geen auth, geen dashboard.

## Railway

Vier services in een project:

| Service | Wat |
|---|---|
| `web` | Next.js, root `apps/web` |
| `worker` | Node, root `apps/worker`, start `node dist/index.js` |
| `postgres` | Railway Postgres, extensies vector en pg_trgm aanzetten |
| cron | Railway cron, drie schema's, zie onder |

Cron:
- `0 5 * * 1-5` ochtendbriefing
- `0 14 * * 5` vrijdagdigest
- `0 3 * * *` `select mark_stale_commitments(21)`

## Resend

Twee toepassingen:

1. **Magic link login.** Enige gebruiker. Token van 15 minuten, opgeslagen als
   hash, eenmalig bruikbaar. Sessie via httpOnly cookie van 30 dagen.
2. **Uitgaande briefings.** Ochtendbriefing en vrijdagdigest.

Domein verifieren in Resend, SPF en DKIM records zetten, en `from` op een
subdomein zoals `hub@mail.jouwdomein.nl`.

## Volgorde

Sprint 1 ingest en extractie. Sprint 2 entiteiten en triage. Sprint 3
reconciliatie en opvolging. Sprint 4 mail inbound. Sprint 5 briefings.

Ga pas door naar de volgende sprint als docs/eval.md slaagt.
